armor:register_armor("ocular_networks:angmallen_helm", {
	description = "Angmallen Helm",
	inventory_image = "poly_armor_angmallen_inv_helmet.png",
	texture = "poly_armor_helmet_angmallen.png",
	preview = "poly_armor_helmet_angmallen_preview.png",
	groups = {armor_head=1, armor_use=100, armor_heal=12},
	armor_groups = {fleshy=10},
	damage_groups = {cracky=3, snappy=3, choppy=3, crumbly=3, level=4},
	reciprocate_damage = true
})

armor:register_armor("ocular_networks:angmallen_chest", {
	description = "Angmallen Chestplate",
	inventory_image = "poly_armor_angmallen_inv_chestplate.png",
	texture = "poly_armor_chestplate_angmallen.png",
	preview = "poly_armor_chestplate_angmallen_preview.png",
	groups = {armor_torso=1, armor_use=100, armor_heal=12},
	armor_groups = {fleshy=30},
	damage_groups = {cracky=3, snappy=3, choppy=3, crumbly=3, level=4},
	reciprocate_damage = true
})

armor:register_armor("ocular_networks:angmallen_legs", {
	description = "Angmallen Greaves",
	inventory_image = "poly_armor_angmallen_inv_leggings.png",
	texture = "poly_armor_leggings_angmallen.png",
	preview = "poly_armor_leggings_angmallen_preview.png",
	groups = {armor_legs=1, armor_use=100, armor_heal=12},
	armor_groups = {fleshy=30},
	damage_groups = {cracky=3, snappy=3, choppy=3, crumbly=3, level=4},
	reciprocate_damage = true
})

armor:register_armor("ocular_networks:angmallen_boots", {
	description = "Angmallen Boots",
	inventory_image = "poly_armor_angmallen_inv_boots.png",
	texture = "poly_armor_boots_angmallen.png",
	preview = "poly_armor_boots_angmallen_preview.png",
	groups = {armor_feet=1, armor_use=100, armor_heal=12},
	armor_groups = {fleshy=10},
	damage_groups = {cracky=3, snappy=3, choppy=3, crumbly=3, level=4},
	reciprocate_damage = true
})

minetest.register_craftitem("ocular_networks:armor_pendant", {
	description = "Angmallen Armor Upgrade Pendant\n"..minetest.colorize("#00affa", "Click to open your upgrade menu.\nPut Upgrade tokens in the inventory to use them."),
	inventory_image = "poly_armor_angmallen_a_upgrade_pendant.png",
	stack_max=1,
	on_use = function(itemstack, user, pointed_thing)
		local inv = user:get_inventory()
		if inv:get_lists().ocn_armor_upgrades then
			minetest.show_formspec(user:get_player_name(), "ocn_armor_upgrades", "size[8,9;]"..default.gui_bg..default.gui_bg_img.."list[current_player;main;0,5;8,4;]list[current_player;ocn_armor_upgrades;0,0;8,4;]")
		else
			inv:set_list("ocn_armor_upgrades", {})
			inv:set_size("ocn_armor_upgrades", 32)
		end
	end
})

local function has_armor_prerequisites(p)
	local inv = minetest.get_inventory({type="detached", name=p:get_player_name().."_armor"})
	return inv:contains_item("armor", "ocular_networks:angmallen_helm") and inv:contains_item("armor", "ocular_networks:angmallen_boots") and inv:contains_item("armor", "ocular_networks:angmallen_chest") and inv:contains_item("armor", "ocular_networks:angmallen_legs")
end

minetest.register_globalstep(function(dtime)
	for _,player in ipairs(minetest.get_connected_players()) do
		if has_armor_prerequisites(player) then
		end
	end
end)